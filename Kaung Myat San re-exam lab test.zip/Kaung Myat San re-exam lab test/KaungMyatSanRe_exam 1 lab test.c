#include <stdio.h>
#include <string.h>
#define MAX 5

struct player 
{
    char name[50];
    float scores;
    int total_score;
    float average_score;
    int performance;
}; 
float calculateaverage(float scores)
{
    return ('int total_score');
}
int main ()
{
   struct player players[MAX];
   int i;
   for (i=0; i<MAX; i++)
   {
    printf ("\nPlayer%d\n",i++);

    printf ("Enter Player:");
    scanf ("%[^\n]",players[i].name);

    printf ("Enter Score:");
    scanf ("%d",&players[i].scores);

    players[i].average_score=calculateaverage(players[i].scores);
   }

   int total_score;
    if (players[i].average_score >=90 && players[i].average_score <=100)
    { 
         strcpy(players[i].performance,"Outstanding");
    } 
    else if (players[i].average_score >=80 && players[i].average_score <=89)
    {
        strcpy(players[i].performance,"Excellent");
    }
    else if (players[i].average_score >=70 && players[i].average_score <=79)
    {
        strcpy(players[i].performance,"Good");
    }
    else if (players[i].average_score >=60 && players[i].average_score <=69)
    {
        strcpy(players[i].performance,"Average");
    }
    else 
    {
        printf ("Needs improvement");
    }
    /*Display report*/

    printf ("\n========================================================================\n");
    printf ("                        SPORTS PERFORMANCE REPORT\n                          ");
    printf ("===========================================================================\n");

    printf ("%-20s%-10s%-15s\n","Player Name","Score","Performance");

    for (i=0; i<MAX; i++)
    {
        printf ("%-20s%-10s%-15s\n",players[i].name,players[i].scores,players[i].performance);
    }

    printf ("==============================================================================\n");

    return 0;

}