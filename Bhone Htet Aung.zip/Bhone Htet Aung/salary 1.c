
#include <stdio.h>
#include <string.h>

#define NUM_EMPLOYEES 5
#define MAX_NAME_LEN 50

// User-defined function to calculate total salary
double calculateTotal(double salaries[], int size) {
    double total = 0.0;
    for (int i = 0; i < size; i++) {
        total += salaries[i];
    }
    return total;
}

// User-defined function to calculate average salary
double calculateAverage(double total, int size) {
    return total / size;
}

// Function to print salary category using if-else statements
void printCategory(double salary) {
    if (salary >= 500000.0) {
        printf("High");
    } else if (salary >= 300000.0) {
        printf("Medium");
    } else if (salary >= 200000.0) {
        printf("Low");
    } else {
        printf("Very Low");
    }
}

int main() {
    char names[NUM_EMPLOYEES][MAX_NAME_LEN];
    double salaries[NUM_EMPLOYEES];

    // 1 & 2 & 3. Input employee information into arrays
    printf("=== ENTER EMPLOYEE DETAILS ===\n");
    for (int i = 0; i < NUM_EMPLOYEES; i++) {
        printf("\nEmployee %d Name: ", i + 1);
        scanf(" %[^\n]", names[i]); // Reads string with spaces

        printf("Employee %d Monthly Salary: ", i + 1);
        scanf("%lf", &salaries[i]);
    }

    // 4 & 5. User-defined function calls for Total and Average
    double totalSalary = calculateTotal(salaries, NUM_EMPLOYEES);
    double avgSalary = calculateAverage(totalSalary, NUM_EMPLOYEES);

    // 6. Use loops to determine highest and lowest salary
    double highestSalary = salaries[0];
    double lowestSalary = salaries[0];

    for (int i = 1; i < NUM_EMPLOYEES; i++) {
        if (salaries[i] > highestSalary) {
            highestSalary = salaries[i];
        }
        if (salaries[i] < lowestSalary) {
            lowestSalary = salaries[i];
        }
    }

    // 7 & 8. Display Formatted Salary Report
    printf("\n=========================================================\n");
    printf("%-20s | %-15s | %-10s\n", "Employee Name", "Salary", "Category");
    printf("---------------------------------------------------------\n");

    for (int i = 0; i < NUM_EMPLOYEES; i++) {
        printf("%-20s | %-15.2f | ", names[i], salaries[i]);
        printCategory(salaries[i]);
        printf("\n");
    }

    printf("=========================================================\n");
    printf("SALARY SUMMARY STATISTICS:\n");
    printf("Total Salary   : %.2f\n", totalSalary);
    printf("Average Salary : %.2f\n", avgSalary);
    printf("Highest Salary : %.2f\n", highestSalary);
    printf("Lowest Salary  : %.2f\n", lowestSalary);
    printf("=========================================================\n");

    return 0;
}