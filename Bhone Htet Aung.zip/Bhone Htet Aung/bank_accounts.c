 #include <stdio.h>

struct Account
{
    int accountNumber;
    char customerName[30];
    float balance;
};

int main()
{
    struct Account acc[5];
    FILE *file;
    int i;

    // Input details of five customers
    printf("Enter details of 5 bank customers:\n\n");

    for (i = 0; i < 5; i++)
    {
        printf("Customer %d\n", i + 1);

        printf("Account Number: ");
        scanf("%d", &acc[i].accountNumber);

        printf("Customer Name: ");
        scanf(" %[^\n]", acc[i].customerName);

        printf("Account Balance: ");
        scanf("%f", &acc[i].balance);

        printf("\n");
    }

    // Open file in write mode
    file = fopen("account.txt", "w");

    if (file == NULL)
    {
        printf("Error opening file!\n");
        return 1;
    }

    // Store records in the file
    for (i = 0; i < 5; i++)
    {
        fprintf(file, "%d %s %.2f\n",
                acc[i].accountNumber,
                acc[i].customerName,
                acc[i].balance);
    }

    // Close the file
    fclose(file);

    // Reopen file in read mode
    file = fopen("account.txt", "r");

    if (file == NULL)
    {
        printf("Error opening file!\n");
        return 1;
    }

    // Display formatted table
    printf("\n\n================ BANK ACCOUNT INFORMATION ================\n");
    printf("%-15s %-25s %-15s\n",
           "Account Number", "Customer Name", "Balance");
    printf("----------------------------------------------------------\n");

    // Read records using fscanf()
    while (fscanf(file, "%d %49s %f",
                  &acc[0].accountNumber,
                  acc[0].customerName,
                  &acc[0].balance) == 3)
    {
        printf("%-15d %-25s %.2f\n",
               acc[0].accountNumber,
               acc[0].customerName,
               acc[0].balance);
    }

    // Close the file
    fclose(file);

    printf("==========================================================\n");

    return 0;
}