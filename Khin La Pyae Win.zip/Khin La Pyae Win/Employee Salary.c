# include <stdio.h>


/* ------- USER-DEFINED FUNCTIONS---------*/
#define NUM_EMPLOYEES 5

// Calculate and return the total of all salaries 
float calculate_total(float salary[], int n)
{
    float total = 0;
    int i;

    for (i = 0; i < n; i++)
    {
        total += salary[i];
    }
    return total;
}

// Calculate and return the average salary 
float calculate_average(float salary[], int n)
{
    float total = calculate_total(salary, n);

    if (n == 0)
        return 0;

    return total / n;
}
// Return the index of the highest salary 
int high(float salary[], int n)
{
    int i, highest = 0;

    for (i = 1; i < n; i++)
    {
        if (salary[i] > salary[highest])
            highest = i;
    }
    return highest;
}

// Return the index of the lowest salary 
int low(float salary[], int n)
{
    int i, lowest = 0;

    for (i = 1; i < n; i++)
    {
        if (salary[i] < salary[lowest])
            lowest = i;
    }
    return lowest;
}

// Classify a salary using if - else and return a category name 
const char *classify_salary(float salary)
{
    if (salary < 200000) {
        printf("Very Low Salary");
    }
     else if (salary >=200000 && salary <=299999) {
        printf("Low Salary ");
     }
    else if (salary >=300000 && salary >499999){
        printf("Medium Salary");
    }
    else {
        printf("High Salary ");
    }
     
}

/* Display the final summary (totals, average, highest, lowest) */
void display_summary(float salary[], float total, float average, int highest, int lowest)
{
    printf("\n================ SUMMARY ================\n");
    printf("Total Salary   : %.2f\n", total);
    printf("Average Salary : %.2f\n", average);
    printf("Highest Salary : %.2f\n", salary[highest]);
    printf("Lowest  Salary : %.2f\n", salary[lowest]);
    printf("=========================================\n");
}

/* ---------- MAIN PROGRAM ---------- */

int main()
{
    char name[NUM_EMPLOYEES][30];   
    float salary[NUM_EMPLOYEES];   
    float total, average;
    int high, low;
    int i;

    // STEP 1: Input 5 employees and their monthly salaries 
    printf("===== ENTER EMPLOYEE INFORMATION =====\n");
    for (i = 0; i < NUM_EMPLOYEES; i++)
    {
        printf("\nEmployee %d\n", i + 1);

        printf("Name: ");
        scanf(" %29[^\n]", name[i]);

        printf("Monthly Salary: ");
        scanf("%f", &salary[i]);
    }

    // STEP 2: Calculate total and average salary using functions
    total   = calculate_total(salary, NUM_EMPLOYEES);
    average = calculate_average(salary, NUM_EMPLOYEES);

    //STEP 3: Determine highest and lowest salary using loops 
    highest = high(salary, NUM_EMPLOYEES);
    lowest  = low(salary, NUM_EMPLOYEES);

    // STEP 4 & 5: Display name, salary and category (if - else) 
    printf("\n%-5s %-15s %-15s %-12s\n", "No", "Name", "Salary", "Category");
    printf("--------------------------------------------------\n");

    for (i = 0; i < NUM_EMPLOYEES; i++)
    {
        printf("%-5d %-15s %-15.2f %-12s\n",
               i + 1,
               name[i],
               salary[i],
               classify_salary(salary[i]));
    }

    /* Display total, average, highest and lowest salary */
    display_summary(salary, total, average, highest, lowest);

    return 0;
}
