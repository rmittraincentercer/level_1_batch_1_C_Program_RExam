#include <stdio.h>

#define NUM_ACCOUNTS 5

// STEP 1: Define the Account structure 
struct Account
{
    int account_number; 
    char customer_name[30]; 
    float balance;        
};

int main()
{
    // 
    struct Account acc[NUM_ACCOUNTS];
    FILE *fp;                         // file pointer             
    int i;

    // STEPS 2 & 3: Input account number, customer name and balance 
    printf("===== ENTER ACCOUNT INFORMATION =====\n");

    for (i = 0; i < NUM_ACCOUNTS; i++)
    {
        printf("\nAccount %d\n", i + 1);

        printf("Account Number: ");
        scanf("%d", &acc[i].account_number);

        printf("Customer Name : ");
        scanf(" %29[^\n]", acc[i].customer_name);

        printf("Balance       : ");
        scanf("%f", &acc[i].balance);
    }

    /* STEP 4: Open account.txt in write mode */
    fp = fopen("account.txt", "w");

    if (fp == NULL)
    {
        printf("Error: could not open file for writing.\n");
        return 1;
    }

    // STEP 5: Store records using fprintf() 
    for (i = 0; i < NUM_ACCOUNTS; i++)
    {
        fprintf(fp, "%d %s %.2f\n",
                acc[i].account_number,
                acc[i].customer_name,
                acc[i].balance);
    }

    // STEP 7: Close the file 
    fclose(fp);
    printf("\nRecords saved to account.txt successfully.\n");

    // STEP 8: Reopen the file in read mode 
    fp = fopen("account.txt", "r");

    if (fp == NULL)
    {
        printf("Error: could not open file for reading.\n");
        return 1;
    }

    /* STEPS 9 & 10: Read using fscanf() and display records */
    printf("\n===== ACCOUNT RECORDS =====\n");

    /* STEP 11: Display all records in a formatted table */
    printf("%-15s %-20s %-15s\n", "Account No", "Customer Name", "Balance");
    printf("--------------------------------------------------\n");

    while (fscanf(fp, "%d %29s %f",
                  &acc[i].account_number,
                  acc[i].customer_name,
                  &acc[i].balance) == 3)
    {
        printf("%-15d %-20s %-15.2f\n",
               acc[i].account_number,
               acc[i].customer_name,
               acc[i].balance);
    }

    // Close the file after reading 
    fclose(fp);

    return 0;
}
