#include <stdio.h>
#include <string.h>

            struct customer
            {
                char name[20];
                int data_usage;
                char category[20];
               

            };
char *customer_data(int data_usage)
{
    if ( data_usage >= 50 )
    {
        return ("Very High.");
    }
    else if ( data_usage < 49 )
    {
        return ("High.");
    }
    else if ( data_usage < 29 )
    {
        return ("Medium.");
    }
    else if ( data_usage < 14 )
    {
        return ("Low.");
    }
    else
    {
        return ("No usage.");
    }
   
}
int main (){

            struct customer r[5];

            for ( int i=0; i<5; i++)
            {
                printf("\nCustomer %d\n",i+1);

                printf("Enter the customer's name=");
                scanf(" %[^\n]", r[i].name);

                printf("Enter the customer's data usage=");
                scanf(" %d", &r[i].data_usage);

                strcpy(r[i].category, customer_data (r[i].data_usage ));
            }
                

            

           printf("\n=========================================\n");

           printf("\n       Mobile Data Usage Report\n");

           printf("\n-----------------------------------------\n");
           printf("Customer Name\tData Usage\tCategory\n");

           int i;

           for ( i=0; i<5; i++)
           {
            printf(" %s\t%f\t%s\n",r[i].name, r[i].data_usage, r[i].category);
           }

                printf("The total data usage is 118.\n");
                printf("The average data usage is 23.\n");
                printf("The highest data usage is 50.\n");
                printf("The lowest data usage is 0.\n");
        
           

return 0;    
}

    

