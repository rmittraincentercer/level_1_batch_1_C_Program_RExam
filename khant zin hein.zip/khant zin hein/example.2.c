#include <stdio.h>

            struct staff
            {
                int staffid;
                char name[30];
                float salary;
            };
int main (){

                struct staff r[5];

                for (int i=0; i<5; i++)
                {

                  printf("\nStaff %d",i+1);

                  printf("Enter the staff ID=");
                  scanf(" %[^\n]", r[i].name);

                  printf("Enter the salary=");
                  scanf(" %f", &r[i].salary);

                }

                FILE *fp;
                fp = fopen ("employee.txt","w");

                if ( fp == NULL )
                {
                    printf(" File cannot be opened.\n");
                    return 1;
                }
                fprintf(fp,"\nStaff Information\n");
                fprintf(fp,"Staff ID\t\t Staff Name\t\t Monthly Salary\n");

                for (int i=0; i<5; i++)
                {
                    fprintf(fp, " %d %s %f\n", r[i].staffid, r[i].name, r[i].salary );
                }
                fclose(fp);

                fp = fopen ("employee.txt","r");

                char header1[100],header2[200];
                fgets (header1,sizeof(header1),fp);
                fgets (header2,sizeof(header2),fp);

                printf("\nStaff Information\n");
                printf("\nStaff ID\tStaff Name\tMonthly Salary\n");

                int i;

                for (i=0; i<5; i++)
                {
                    fscanf(fp," %d %s %f\n", &r[i].staffid, r[i].name, &r[i].salary);

                    printf(" %d\t%s\t%f\n", r[i].staffid, r[i].name, r[i].salary);
                }
                fclose(fp);

return 0;    
}

